#!/bin/bash

a=10
b=2

let sum=$a+$b
let diff=$a-$b
let prod=$a*$b
let div=$a/$b
# modulo with let requires encapsulation within quotes
let "remainder=$a % $b"
# exponentiation with let requires encapsulation within quotes
let "exponent=$a ** $b"

echo "The sum of the integers is $sum"
echo "The difference between the integers is $diff"
echo "The product of the integers is $prod"
echo "The dividend of the integers is $div"
echo "The remainder after modulo is $remainder"
echo "The result after exponentiation is $exponent"

exit 0