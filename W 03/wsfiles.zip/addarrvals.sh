#!/bin/bash

declare -a vals
vals=(3.05 4.12 6.34)

sum=`expr ${vals[0]} + ${vals[1]} + ${vals[2]}`

echo "${vals[0]} plus ${vals[1]} plus ${vals[2]} is $sum2"

exit 0