#!/bin/bash

echo "OPERATION CODES:"
echo -e "A - Addition, S - Subtraction, M - Multiplication, D - Division, E - Exponentation\n"

read -p "Enter two integers and an operation code, e.g. 10 20 M: " int1 int2 opr

# echo $int1
# echo $int2
# echo $opr

case $opr in
   A|a)
    let sum=$int1+$int2
    echo $sum
    ;;
   S|s)
    diff=`echo 'scale=2;'"$int1 - $int2" | bc -l`
    echo $(printf %.2f $diff)
    ;;
   M|m) echo "Multiply";;
   D|d)
    divid=$(echo $int1 $int2 | awk '{printf "%.2f", $1/$2}')
    echo $divid
    ;;
   E|e) echo "Exponentiate";;
   *) echo "Invalid option; exiting program" && exit 1;;
esac

exit 0