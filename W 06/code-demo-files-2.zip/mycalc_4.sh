#!/bin/bash

# The calculator with looping implemented so that user can reuse as often as they wish
   # all inputs are validated using a function, and 
   # division by zero error is handled gracefully
   # Error messages output in red for clarity

RED='\033[0;31m'
NC='\033[0m' # No Color

   chinp()
   {
      if [[ $# -eq 3 ]] && [[ $1 =~ ^[0-9]+\.?[0-9]*$ ]] && [[ $2 =~ ^[0-9]+\.?[0-9]*$ ]] && [[ $3 =~ ^[ASMDEasmde]{1}$ ]]; then
         chkrslt=true
      else
         chkrslt=false
      fi

      echo $chkrslt

   }

while true; do

   while true; do

      echo "OPERATION CODES:"
      echo -e "A - Addition, S - Subtraction, M - Multiplication, D - Division, E - Exponentiation\n"

      read -p "Enter two integers and an operation code, e.g. 10 20 M: " int1 int2 opr

      tstresult=$(chinp $int1 $int2 $opr)

      # echo "The function test result is $tstresult"

      if [[ $tstresult == "false" ]]; then
         echo -e "\n${RED}There was problem with your inputs; please try again${NC}\n"
      else
         break
      fi

   done

case $opr in
   A|a)
      echo $(echo $int1 $int2 | awk '{printf "%.2f", $1+$2}')
      ;;
   S|s)
      echo $(echo $int1 $int2 | awk '{printf "%.2f", $1-$2}')
      ;;
   M|m)
      echo $(echo $int1 $int2 | awk '{printf "%.2f", $1*$2}')
      ;;
   D|d)
      if [[ $int2 -eq 0 ]]; then
         echo -e "${RED}Sorry, you cannot divide by 0; operation cannot be performed.${NC}"
      else
         echo $(echo $int1 $int2 | awk '{printf "%.2f", $1/$2}')
      fi
      ;;
   E|e)
      echo $(echo $int1 $int2 | awk '{printf "%.2f", $1**$2}')
      ;;
   *)
      echo "Invalid option(s) entered, no claculation can be performed"
      # exit 1
      ;;
esac

read -p "Would you like to perform another operation? (y/n)" resp

case $resp in
   n|N) break;;
esac

done

echo "Thanks for using Vince's custom calculator; exiting now."

exit 0