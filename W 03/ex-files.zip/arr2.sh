#!/bin/bash

declare -a someStrings=("Jan" "Feb" "Mar" "Apr" "May" "June")
declare -a someInts=(1 2 3 4 5 6)
declare -a mixedData=("Jan" 2 "Feb" 4 "Mar" 6)
# This gets us a count of array members
arrCount=${#mixedData[@]}

# This shows us the array member count
echo -e "The mixedData array contains $arrCount members; these being:\n"

# The array member count being used in a c-style loop
for (( i=1; i<=$arrCount; i++)); do
    # an offset to ensure array members are access from position 0
    offset=$(( i-1 ))
    # print each array member to the terminal in its own line
    echo ${mixedData[$offset]}
done

exit 0