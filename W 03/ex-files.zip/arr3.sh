#!/bin/bash

declare -a someStrings=("Jan" "Feb" "Mar" "Apr" "May" "June")
declare -a someInts=(1 2 3 4 5 6)
declare -a mixedData=("Jan" 2 "Feb" 4 "Mar" 6)
declare -a empNames

# Get each user name from empnames.txt and add to array
for name in $(cat empnames.txt); do
    empNames+=("$name")
done

# Get the count of array members
arrCount=${#empNames[@]}

# Set c-style loop based in array count
for (( i=1; i<=$arrCount; i++)); do
    # offset to start from position 0
    offset=$(( i-1 ))
    # print each array member 
    echo ${empNames[$offset]}
done

exit 0