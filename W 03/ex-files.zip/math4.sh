#!/bin/bash

a=10
b=2

sum=$(($a + $b))
diff=$(($a - $b))
prod=$(($a * $b))
divid=$(($a / $b))
remain=$(($a % $b))
expon=$(($a ** $b))

echo "The sum of the integers is $sum"
echo "The difference between the integers is $diff"
echo "The product of the integers is $prod"
echo "The dividend of the integers is $divid"
echo "The remainder after modulo is $remain"
echo "The result after exponentiation is $expon"

exit 0