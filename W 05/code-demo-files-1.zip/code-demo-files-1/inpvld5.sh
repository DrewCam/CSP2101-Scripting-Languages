#!/bin/bash

grep -n 'y[ea]*s' list.txt # e and a can be there 0 or more times.

exit 0