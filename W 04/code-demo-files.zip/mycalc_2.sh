#!/bin/bash

# The calculator with looping implemented so that user can reuse as often as they wish

while true; do

echo "OPERATION CODES:"
echo -e "A - Addition, S - Subtraction, M - Multiplication, D - Division, E - Exponentiation\n"

read -p "Enter two integers and an operation code, e.g. 10 20 M: " int1 int2 opr

case $opr in
   A|a)
      echo $(echo $int1 $int2 | awk '{printf "%.2f", $1+$2}')
      ;;
   S|s)
      echo $(echo $int1 $int2 | awk '{printf "%.2f", $1-$2}')
      ;;
   M|m)
      echo $(echo $int1 $int2 | awk '{printf "%.2f", $1*$2}')
      ;;
   D|d)
      echo $(echo $int1 $int2 | awk '{printf "%.2f", $1/$2}')
      ;;
   E|e)
      echo $(echo $int1 $int2 | awk '{printf "%.2f", $1**$2}')
      ;;
   *)
      echo "Invalid option(s) entered, no claculation can be performed"
      # exit 1
      ;;
esac

read -p "Would you like to perform another operation? (y/n)" resp

case $resp in
   n|N) break;;
esac

done

echo "Thanks for using Vince's custom calculator; exiting now."

exit 0