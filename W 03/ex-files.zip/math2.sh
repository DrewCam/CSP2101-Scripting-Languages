#!/bin/bash

a=10
b=2

declare -i sum=$a+$b
declare -i diff=$a-$b
declare -i prod=$a*$b
declare -i divid=$a/$b
declare -i remain=$a%$b
declare -i expon=$a**$b

echo "The sum of the integers is $sum"
echo "The difference between the integers is $diff"
echo "The product of the integers is $prod"
echo "The dividend of the integers is $divid"
echo "The remainder after modulo is $remain"
echo "The result after exponentiation is $expon"

exit 0