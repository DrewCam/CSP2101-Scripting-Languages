#!/bin/bash
# Test that entered value is integer >= 5 and <= 10

while true; do # begin loop
    read -p 'Enter a number between 5 and 10 inclusive: ' var # prompt user for a number between 1 and 10 inclusive
        if [[ $var -ge 5 ]] && [[ $var -le 10 ]]; then # if invalid number given, loop back to prompt
            break
        else
            echo "Invalid input, please try again"
        fi
done

echo "Thank you, you have entered $var" # echo the input number to terminal
exit 0