#!/bin/bash

a=10
b=2

sum=`expr $a + $b`
diff=`expr $a - $b`
prod=`expr $a \* $b`
divid=`expr $a / $b`
remain=`expr $a % $b`

echo "The sum of the integers is $sum"
echo "The difference between the integers is $diff"
echo "The product of the integers is $prod"
echo "The dividend of the integers is $divid"
echo "The remainder after modulo is $remain"

exit 0