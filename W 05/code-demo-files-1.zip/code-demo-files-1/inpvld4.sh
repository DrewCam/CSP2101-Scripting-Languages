#!/bin/bash

read -p 'Please enter an integer: ' myint

if [[ $myint =~ ^[0-9]{5}$ ]]; then #has to be an integer of 5 digits no more or less.
    echo "This is valid"
else
    echo "This in not valid"
fi

exit 0