#!/bin/bash

RED='\033[00;31m' # Use ${RED} in code
YELLOW='\033[00;33m' # Use ${YELLOW} in code
BLUE='\033[00;34m' # Use ${BLUE} in code
GREEN='\033[00;32m' # Use ${GREEN} in code
NCOL='\033[0m' # Use ${NCOL} in code to set back to default