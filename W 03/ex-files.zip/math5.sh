#!/bin/bash

# Convert Fahrenheit to Celsius using the bash calculator - bc

read -p "Please enter a temperature in Fahrenheit: " fh

# decimalise the conversion ratio from Fahrenheit to Celsius
conv=`echo 'scale=5;'"5 / 9" | bc -l` # 5/9 is equal to 0.55555

# Calculate the Celsius equivalent
celcius=`echo "($fh - 32) * $conv" | bc -l`

# Output the result
echo "$fh degrees Fahrenheit is equivalent to $(printf %.2f $celcius) degrees Celsius"

exit 0