#!/bin/bash

grep -En "^regex can be (very )+confusing" wild1.txt

exit 0