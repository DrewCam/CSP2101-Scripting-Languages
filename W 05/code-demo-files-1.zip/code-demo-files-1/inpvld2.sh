#!/bin/bash

# Output the sales amounts in results.txt to the terminal ensuring float values are correctly displayed
# This demonstrates a for loop in conjunction with a if statment, regex and printf

for line in $(cat results.txt); do # declare a for loop using the cat command to insert a list of values
    if ! [[ $line =~ ^[0-9]+$ ]]; then # use regex to check if value is a float
        printf "$%.2f\n" "$line" # if a float, format accordingly
    else
        echo "\$$line" # if an integer, format accordingly
    fi
done

exit 0