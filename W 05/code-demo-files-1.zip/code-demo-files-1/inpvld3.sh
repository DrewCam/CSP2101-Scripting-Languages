#!/bin/bash

while true; do # begin loop
    read -p 'Enter an integer or float number: ' var # prompt user for a number (int or float)
        if [[ $var =~ ^[0-9]+\.?[0-9]*$ ]]; then # if invalid number given, loop back to prompt
            break
        else
            echo "Invalid input, please try again"
        fi
done

echo "Thank you, you have entered $var" # echo the input number to terminal
exit 0