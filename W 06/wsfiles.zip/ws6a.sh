#!/bin/bash

getsumlines() {
    # Place your function code here
}

getsumlines attdata.txt

cat results.txt

exit 0