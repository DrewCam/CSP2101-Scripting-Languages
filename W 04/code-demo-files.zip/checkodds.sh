#!/bin/bash

# Place all numbers in ranums.csv into an array then, using this array
    # output to screen all odd numbers greater than 15 but less than 80

declare -a numlist

for num in $(cat ranums.csv); do
    numlist+=("$num")
done

arrcnt=${#numlist[@]}

for (( i=0; i<$arrcnt; i++ )); do
    if [[  ${numlist[$i]} -gt 15 ]] && [[  ${numlist[$i]} -lt 80 ]]; then
        if [[ ${numlist[$i]}%2 -gt 0 ]]; then
            echo ${numlist[$i]}
        fi
    else
        continue
    fi
done

exit 0