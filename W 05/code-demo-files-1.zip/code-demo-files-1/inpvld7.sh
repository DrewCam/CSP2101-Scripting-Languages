#!/bin/bash

# Prompt user for a string consisting of 10 lowercase characters exactly

while true; do # declare while loop that will only end with a specific command, e.g. break, exit etc
    read -p 'Enter a ten letter string: ' sname # get user input
    if [[ ${#sname} -eq 10 ]] && [[ $sname =~ ^[a-z]+$ ]]; then # Use regex to test input is 10 lowercase characters
        echo "Valid input"
        break # If input is valid, break out of the while loop
    else
        echo "Invalid input" # If invalid input, loop back to prompt
    fi
done

exit 0