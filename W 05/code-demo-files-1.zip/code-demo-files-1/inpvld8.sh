#!/bin/bash

match=0 salecnt=0 salettl=0
declare -a STAFF
cat staff-sales.csv  | cut -f1 -d , | sort -u > temp
for item in $( cat temp ); do
    STAFF+=("$item")
done

while true; do
    for i in ${STAFF[@]}; do
        echo -n "[$i] "
    done
    echo -e "\n"
    read -p "Please enter a username from the list above: " stffnme

    for i in ${STAFF[@]}; do
        if [[ "$stffnme" == "$i" ]]; then
            match=1
        fi
    done

    if [[ $match -eq 1 ]]; then
        break
    else
        echo -e "No matching staff member found. Please try again.\n"
    fi

done

for item in $( cat staff-sales.csv ); do
    if [[ "$( echo $item | cut -f1 -d , )" == "$stffnme" ]]; then
        ((salecnt++))
        salettl=$(echo $salettl $( echo $item | cut -f2 -d , ) | awk '{printf "%.2f", $1+$2}')
    fi
done

echo "The staff member [$stffnme] has made [$salecnt] sales for a total of [\$$salettl]"

exit 0