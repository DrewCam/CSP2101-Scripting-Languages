#!/bin/bash

echo -e "1) Menu Option 1\n2) Menu Option 2\n3) Menu Option 3"

read -p 'Please select a menu option [1, 2 or 3]: ' selopt



case $selopt in
   1) echo "You have selected menu option 1";;
   2) echo "You have selected menu option 2";;
   3) echo "You have selected menu option 3";;
   *) echo "Invalid selection; exiting program" && exit 1;;
esac

exit 0