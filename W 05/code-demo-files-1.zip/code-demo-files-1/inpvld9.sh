#!/bin/bash

# Use a regex test for standard email addresses
# This is an example only, and this would need to be further modified for more unusual email examples

while true; do # begin loop
    read -p 'Enter an email address: ' email # prompt user for an email address
        if [[ $email =~ ^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z]{2,4}\.?[a-zA-Z]{2,2}?$ ]]; then # if valid email
            break
        else
            echo "Invalid email, please try again"
        fi
done

echo "Thank you, you have entered $email" # echo the email to terminal
exit 0