#!/bin/bash

# Get floating point result outputs using awk

f1=6.22
f2=3.33

sum=$(echo $f1 $f2 | awk '{printf "%.2f", $1+$2}')
diff=$(echo $f1 $f2 | awk '{printf "%.2f", $1-$2}')
prod=$(echo $f1 $f2 | awk '{printf "%.2f", $1*$2}')
divid=$(echo $f1 $f2 | awk '{printf "%.2f", $1/$2}')

echo "The sum of $f1 and $f2 is $sum"
echo "The difference between $f1 and $f2 is $diff"
echo "The product of $f1 and $f2 is $prod"
echo "The dividend of $f1 and $f2 is $divid"

exit 0