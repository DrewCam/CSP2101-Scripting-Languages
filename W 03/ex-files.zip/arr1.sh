#!/bin/bash

declare -a someStrings=("Jan" "Feb" "Mar" "Apr" "May" "June")
declare -a someInts=(1 2 3 4 5 6)
declare -a mixedData=("Jan" 2 "Feb" 4 "Mar" 6)
arrCount=${#mixedData[*]} # This gets us a count of array members

# * will place all items on one line
for item in "${someStrings[*]}"; do
    echo "$item"
done

echo ""

# @ will place each item on its own line
for item in "${someStrings[@]}"; do
    echo "$item"
done

exit 0